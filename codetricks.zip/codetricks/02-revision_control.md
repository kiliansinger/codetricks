# Revision control

Revision control is very useful. Just imagine you write your thesis and suddenly you delete a part without realizing it. you safe it and then you write more. At some point you realize the problem. With revision control you can follow back each of your steps.

And here we use it that you can update your codetricks course. But the great part of git is that you can work in teams. It was invented by Linus Thorwald who wrote Linux. We use it in science when we program large simulation programs in teams or sofisticated experimental control systems.

Lets install it.

now all you have to do to update is type ``git pull`` from the command line to get updates.
For the lazy ones I have it in the hint...

And now you can see more chapters and also this text was updated.
If you want to learn more about git you can start here: https://rogerdudler.github.io/git-guide/

Have also a look I updated the [01-welcome](./01-welcome.md) with hints where to learn more about Markdown.


